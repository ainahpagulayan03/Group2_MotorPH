/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.revised.motorph_payroll_mgt;

/**
 *
 * @author rashni alicando
 */
public class MotorPh_Payroll_mgt {

    public static void main(String[] args) {
        
        signin_page sign = new signin_page();
        sign.setVisible(true);
        sign.pack();
        sign.setLocationRelativeto(null);
        
        
        
    }
}
